
import streamlit as st
import requests

st.set_page_config(page_title="Nationality & Author Profiling", layout="centered")

st.title("🌍 Nationality & Author Profiling System")

backend_url = "http://localhost:8000/analyze"

user_input = st.text_area("Enter text (tweet or user content):", height=150)

if st.button("Analyze"):
    if user_input.strip() == "":
        st.error("❗ Please enter some text to analyze.")
    else:
        with st.spinner("Analyzing..."):
            try:
                response = requests.post(backend_url, json={"text": user_input})
                response.raise_for_status()
                result = response.json()

                st.subheader("📊 Results")

                st.markdown("### 🌍 Nationality Prediction")
                st.write(f"**Country:** {result['nationality']['label']}")
                st.progress(min(result['nationality']['score'], 1.0))
                st.caption(f"Confidence: {result['nationality']['score']:.2f}")

                st.markdown("### 🧑‍💻 Author Profile Prediction")
                st.write(f"**Class:** {result['profile']['label']}")
                st.progress(min(result['profile']['score'], 1.0))
                st.caption(f"Confidence: {result['profile']['score']:.2f}")

            except requests.exceptions.RequestException as e:
                st.error(f"❗ Error: Could not connect to backend API.\n{e}")
