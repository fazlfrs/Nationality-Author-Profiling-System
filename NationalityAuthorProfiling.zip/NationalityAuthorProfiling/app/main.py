
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from models import load_models

app = FastAPI()

# Enable CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

nationality_model, profiling_model = load_models()

# Expanded candidate country list
countries = [
    "United States", "Canada", "Mexico", "Spain", "France", "Germany", "India",
    "China", "Japan", "Brazil", "Argentina", "Nigeria", "South Africa",
    "Egypt", "Australia", "Russia", "Italy", "United Kingdom", "Pakistan", "Turkey"
]

@app.post("/analyze")
async def analyze(request: Request):
    data = await request.json()
    text = data.get("text", "")

    # Predict nationality
    nationality_result = nationality_model(text, candidate_labels=countries)
    top_nationality = {
        "label": nationality_result['labels'][0],
        "score": nationality_result['scores'][0]
    }

    # Predict author profile (placeholder)
    raw_profile = profiling_model(text, truncation=True)[0]
    profile_result = {
        "label": "Male" if raw_profile['label'] == 'LABEL_0' else "Female",
        "score": raw_profile['score']
    }

    return {
        "nationality": top_nationality,
        "profile": profile_result
    }
