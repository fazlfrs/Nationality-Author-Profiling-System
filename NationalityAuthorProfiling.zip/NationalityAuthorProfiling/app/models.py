
from transformers import pipeline

def load_models():
    # Zero-shot classification for nationality
    nationality_model = pipeline("zero-shot-classification", model="facebook/bart-large-mnli")
    # Placeholder for profiling model
    profiling_model = pipeline("text-classification", model="distilbert-base-uncased")
    return nationality_model, profiling_model
